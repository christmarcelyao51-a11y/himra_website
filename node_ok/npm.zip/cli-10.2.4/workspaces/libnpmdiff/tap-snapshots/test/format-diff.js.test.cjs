/* IMPORTANT
 * This snapshot file is auto-generated, but designed for humans.
 * It should be checked into source control and tracked carefully.
 * Re-generate by setting TAP_SNAPSHOT=1 and running tests.
 * Make sure to inspect the output below.  Do not ignore changes!
 */
'use strict'
exports[`test/format-diff.js TAP added file > should output expected added file diff result 1`] = `
diff --git a/foo.js b/foo.js
new file mode 100755
index v1.0.0..v2.0.0 
--- a/foo.js
+++ b/foo.js
@@ -0,0 +1,2 @@
+"use strict"
+module.exports = "foo"
`

exports[`test/format-diff.js TAP binary file > should output expected bin file diff result 1`] = `
diff --git a/foo.jpg b/foo.jpg
index v1.0.0..v2.0.0 100644
--- a/foo.jpg
+++ b/foo.jpg
`

exports[`test/format-diff.js TAP changed file mode > should output expected changed file mode diff result 1`] = `
diff --git a/foo.js b/foo.js
old mode 100644
new mode 100755
index v1.0.0..v2.0.0 
--- a/foo.js
+++ b/foo.js
`

exports[`test/format-diff.js TAP colored output > should output expected colored diff result 1`] = `
[33mdiff --git a/foo.js b/foo.js[39m
[33mindex v1.0.0..v2.0.0 100644[39m
[33m--- a/foo.js[39m
[33m+++ b/foo.js[39m
[35m@@ -1,2 +1,2 @@[39m
 "use strict"
[31m-module.exports = "foo"[39m
[32m+module.exports = "foobar"[39m
`

exports[`test/format-diff.js TAP diff options > should output expected diff result 1`] = `
diff --git before/foo.js after/foo.js
index v1.0.0..v2.0.0 100644
--- before/foo.js
+++ after/foo.js
@@ -4,4 +4,6 @@
 const c = "c"
+const d = "d"
 module.exports = () => a+
 b+
-c
+c+
+d
`

exports[`test/format-diff.js TAP diffUnified=0 > should output no context lines in output 1`] = `
diff --git a/foo.js b/foo.js
index v1.0.0..v2.0.0 100644
--- a/foo.js
+++ b/foo.js
@@ -3,2 +3,3 @@
-const b = "b"
-const c = "c"
+  const b = "b"
+  const c = "c"
+  const d = "d"
@@ -7,1 +8,2 @@
-c
+c+
+d
`

exports[`test/format-diff.js TAP format multiple files patch > should output expected result for multiple files 1`] = `
diff --git a/foo.js b/foo.js
index v1.0.0..v1.1.1 100644
--- a/foo.js
+++ b/foo.js
@@ -1,2 +1,2 @@
 "use strict"
-module.exports = "foo"
+module.exports = "foobar"
diff --git a/lib/utils.js b/lib/utils.js
index v1.0.0..v1.1.1 100644
--- a/lib/utils.js
+++ b/lib/utils.js
@@ -1,3 +1,4 @@
 "use strict"
 const bar = require("./bar.js")
-module.exports = () => bar
+module.exports =
+  () => bar + "util"
`

exports[`test/format-diff.js TAP format removed file > should output expected removed file diff result 1`] = `
diff --git a/foo.js b/foo.js
deleted file mode 100644
index v1.0.0..v2.0.0 
--- a/foo.js
+++ b/foo.js
@@ -1,2 +0,0 @@
-"use strict"
-module.exports = "foo"
/ No newline at end of file
`

exports[`test/format-diff.js TAP format simple diff > should output expected diff result 1`] = `
diff --git a/foo.js b/foo.js
index v1.0.0..v2.0.0 100644
--- a/foo.js
+++ b/foo.js
@@ -1,2 +1,2 @@
 "use strict"
-module.exports = "foo"
+module.exports = "foobar"
`

exports[`test/format-diff.js TAP noPrefix > should output result with no prefixes 1`] = `
diff --git foo.js foo.js
index v1.0.0..v2.0.0 100644
Index: foo.js
--- foo.js
+++ foo.js
@@ -1,2 +1,2 @@
 "use strict"
-module.exports = "foo"
+module.exports = "foobar"
`

exports[`test/format-diff.js TAP nothing to diff > should output empty result 1`] = `

`

exports[`test/format-diff.js TAP respect --tag-version-prefix option > should output expected diff result 1`] = `
diff --git a/foo.js b/foo.js
index b1.0.0..b2.0.0 100644
--- a/foo.js
+++ b/foo.js
@@ -1,2 +1,2 @@
 "use strict"
-module.exports = "foo"
+module.exports = "foobar"
`

exports[`test/format-diff.js TAP using --name-only option > should output expected diff result 1`] = `
foo.js
lib/utils.js
`
